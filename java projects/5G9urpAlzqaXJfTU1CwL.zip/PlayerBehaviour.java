public interface PlayerBehaviour{
    public void move();
    public void attack(Monster target);
    public void pickUp(Item item);
}
