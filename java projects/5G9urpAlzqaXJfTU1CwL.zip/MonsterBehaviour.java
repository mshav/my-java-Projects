public interface MonsterBehaviour{
    public void attack(Player target);
}
