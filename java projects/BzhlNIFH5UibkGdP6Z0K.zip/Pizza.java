public class Pizza{
	private String base;
	private String topping;

	public Pizza(String base, String topping){
		this.base = base;
		this.topping = topping;
	}
	public String getBase(){
		return this.base;
	}
	public String getTopping(){
		return this.topping;
	}
}
